import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:my_app/features/auth/presentation/screens/client_register_screen.dart';

void main() {
  testWidgets('client registration uses the shared Figma design', (
    tester,
  ) async {
    tester.view.physicalSize = const Size(364, 1024);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);

    await tester.pumpWidget(const MaterialApp(home: ClientRegisterScreen()));
    await tester.pumpAndSettle();

    expect(find.text('Create Account'), findsOneWidget);
    expect(find.text('Signing up as Client'), findsOneWidget);
    expect(find.text('Signing up as Worker'), findsNothing);
    expect(find.text('Primary Service Category'), findsNothing);
    expect(find.byType(TextFormField), findsNWidgets(2));
    expect(find.text('Home'), findsNothing);
    expect(find.text('History'), findsNothing);
    expect(find.text('Message'), findsNothing);
    expect(find.text('Profile'), findsNothing);
  });

  testWidgets('client registration fields accept and display input', (
    tester,
  ) async {
    tester.view.physicalSize = const Size(364, 1024);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);

    await tester.pumpWidget(const MaterialApp(home: ClientRegisterScreen()));
    await tester.pumpAndSettle();

    final fields = find.byType(TextFormField);
    await tester.enterText(fields.at(0), 'Alex');
    await tester.enterText(fields.at(1), 'Client');

    expect(find.text('Alex'), findsOneWidget);
    expect(find.text('Client'), findsOneWidget);
  });

  testWidgets('profile photo overlaps the curved account panel', (
    tester,
  ) async {
    tester.view.physicalSize = const Size(364, 1024);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);

    await tester.pumpWidget(const MaterialApp(home: ClientRegisterScreen()));
    await tester.pumpAndSettle();

    final avatar = tester.getRect(
      find.byKey(const ValueKey('client-registration-profile-avatar')),
    );
    final panel = tester.getRect(
      find.byKey(const ValueKey('client-registration-curved-panel')),
    );

    expect(avatar.top, lessThan(panel.top));
    expect(avatar.bottom, greaterThan(panel.top));
  });
}
