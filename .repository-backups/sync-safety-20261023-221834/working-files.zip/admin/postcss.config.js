export default {
  plugins: {},
}
