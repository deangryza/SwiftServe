import useAdminData from '../lib/useAdminData';
import DataState from '../components/DataState';
import { apiRequest } from '../lib/api';
import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import {
  Users,
  CheckCircle2,
  Clock,
  XCircle,
  Ban,
} from "lucide-react";
import toast from "react-hot-toast";


import UserFilters from "./UserFilters";
import UserTable from "./UserTable";
import UserDetailsModal from "./UserDetailsModal";

const SUMMARY_CONFIG = [
  {
    key: "Total",
    label: "Total Users",
    icon: Users,
    color: "text-blue-600 bg-blue-50",
  },
  {
    key: "Approved",
    label: "Approved",
    icon: CheckCircle2,
    color: "text-green-600 bg-green-50",
  },
  {
    key: "Pending",
    label: "Pending",
    icon: Clock,
    color: "text-orange-600 bg-orange-50",
  },
  {
    key: "Rejected",
    label: "Rejected",
    icon: XCircle,
    color: "text-red-600 bg-red-50",
  },
  {
    key: "Suspended",
    label: "Suspended",
    icon: Ban,
    color: "text-gray-600 bg-gray-100",
  },
];

export default function UserManagement() {
  const { data: userList, setData: setUserList, loading, error } = useAdminData('users');
  const [searchTerm, setSearchTerm] = useState("");
  const [roleFilter, setRoleFilter] = useState("All");
  const [statusFilter, setStatusFilter] = useState("All");
  const [selectedUser, setSelectedUser] = useState(null);

  // ----------------------------------------
  // SUMMARY COUNTS
  // ----------------------------------------

 const counts = useMemo(() => {
  return {
    Total: userList.length,

    Approved: userList.filter(
      (user) =>
        user?.status === "Verified" ||
        user?.status === "Active" ||
        user?.status === "Approved"
    ).length,

    Pending: userList.filter(
      (user) =>
        user?.status === "Pending" ||
        user?.status === "Under Review"
    ).length,

    Rejected: userList.filter(
      (user) => user?.status === "Rejected"
    ).length,

    Suspended: userList.filter(
      (user) => user?.status === "Suspended"
    ).length,
  };
}, [userList]);

  // ----------------------------------------
  // SEARCH + FILTER
  // ----------------------------------------

  const filteredUsers = useMemo(() => {
  const term = searchTerm.trim().toLowerCase();

  return userList.filter((user) => {
    const name = String(user?.name ?? "").toLowerCase();
    const id = String(user?.id ?? "").toLowerCase();
    const category = String(user?.category ?? "").toLowerCase();
    const location = String(user?.location ?? "").toLowerCase();

    const matchesSearch =
      !term ||
      name.includes(term) ||
      id.includes(term) ||
      category.includes(term) ||
      location.includes(term) || String(user.email || "").toLowerCase().includes(term) || String(user.phone || "").includes(term);

    const role =
      user?.role === "Worker"
        ? "Worker"
        : "Client";

    const matchesRole =
      roleFilter === "All" ||
      role === roleFilter;

    const matchesStatus =
      statusFilter === "All" ||
      user?.status === statusFilter;

    return matchesSearch && matchesRole && matchesStatus;
  });
}, [
  userList,
  searchTerm,
  roleFilter,
  statusFilter,
]);

  // ----------------------------------------
  // STATUS UPDATE
  // ----------------------------------------

  const updateStatus = async (user, newStatus, message) => {
    if (!user) return;
    if (user.role === 'Worker' && ['Approved', 'Rejected'].includes(newStatus) && user.status !== 'Suspended') { window.location.assign('/dashboard/verification'); return; }
    try {
      const { item } = await apiRequest('/api/admin/users/' + encodeURIComponent(user.id), { method: 'PATCH', body: JSON.stringify({ status: newStatus }) });
      setUserList(previous => previous.map(current => current.id === item.id ? item : current));
      toast.success(message);
    } catch (failure) { toast.error(failure.message); }
  };

  const handleApprove = (user) => {
    updateStatus(
      user,
      "Approved",
      `${user?.name ?? "User"} has been approved.`
    );
  };

  const handleReject = (user) => {
    updateStatus(
      user,
      "Rejected",
      `${user?.name ?? "User"} has been rejected.`
    );
  };

  const handleSuspend = (user) => {
    updateStatus(
      user,
      "Suspended",
      `${user?.name ?? "User"} has been suspended.`
    );
  };

  const handleReactivate = (user) => {
    updateStatus(
      user,
      "Approved",
      `${user?.name ?? "User"} has been reactivated.`
    );
  };

  // ----------------------------------------
  // PAGE
  // ----------------------------------------

  return (
    <div className="space-y-6">
      <DataState loading={loading} error={error} />
      {/* PAGE HEADER */}
      <div>
        <h1 className="text-2xl font-semibold text-gray-900">
          User Management
        </h1>

        <p className="mt-1 text-sm text-gray-500">
          Review, verify, and manage all registered clients and workers.
        </p>
      </div>

      {/* SUMMARY CARDS */}
      <div className="grid grid-cols-1 gap-3 min-[420px]:grid-cols-2 sm:grid-cols-3 sm:gap-4 lg:grid-cols-5">
        {SUMMARY_CONFIG.map((card, index) => {
          const Icon = card.icon;

          return (
            <motion.div
              key={card.key}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{
                duration: 0.25,
                delay: index * 0.05,
              }}
              className="rounded-xl bg-white p-4 shadow-sm ring-1 ring-gray-100"
            >
              <div
                className={`mb-3 inline-flex rounded-lg p-2 ${card.color}`}
              >
                <Icon className="h-5 w-5" />
              </div>

              <p className="text-2xl font-semibold text-gray-900">
                {counts[card.key]}
              </p>

              <p className="text-xs text-gray-500">
                {card.label}
              </p>
            </motion.div>
          );
        })}
      </div>

      {/* FILTERS */}
      <UserFilters
        searchTerm={searchTerm}
        onSearchChange={setSearchTerm}
        roleFilter={roleFilter}
        onRoleChange={setRoleFilter}
        statusFilter={statusFilter}
        onStatusChange={setStatusFilter}
      />

      {/* USER TABLE */}
      <UserTable
        users={filteredUsers}
        onView={setSelectedUser}
        onApprove={handleApprove}
        onReject={handleReject}
        onSuspend={handleSuspend}
        onReactivate={handleReactivate}
      />

      {/* USER DETAILS MODAL */}
      <UserDetailsModal
        user={selectedUser}
        onClose={() => setSelectedUser(null)}
      />
    </div>
  );
}
